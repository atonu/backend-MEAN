// const mongoose = require('mongoose');
const mongoose = require('mongodb');
// mongoose.set('useNewUrlParser', true);
// mongoose.set('useUnifiedTopology', true);
try {
mongoose.connect('mongodb://localhost:27017/CrudDB',{useUnifiedTopology: true}), (err) => {
if (!err){
        console.log('successfull');
    } else {
        console.log('Error: ' + JSON.stringify(err,undefined,2));
    }
}
} catch(e) {
    console.error(e);
}
// mongoose.createConnection('mongodb://localhost:27017/CrudDB', { useNewUrlParser: true,useUnifiedTopology: true });
// mongoose.createConnection(uri, { useNewUrlParser: true });
module.exports = mongoose